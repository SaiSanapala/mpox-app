// app.js
document.addEventListener('DOMContentLoaded', () => {
    const questions = [
        { text: "Do you have a fever?", symptom: "fever" },
        { text: "Is your fever above 38°C (100.4°F)?", symptom: "high_fever", dependsOn: "fever" },
        { text: "Are you experiencing a rash?", symptom: "rash" },
        { text: "Is the rash spreading to multiple parts of your body?", symptom: "spreading_rash", dependsOn: "rash" },
        { text: "Do you have swollen lymph nodes?", symptom: "swollen_lymph_nodes" },
        { text: "Are your lymph nodes painful to touch?", symptom: "painful_lymph_nodes", dependsOn: "swollen_lymph_nodes" },
        { text: "Do you have a headache?", symptom: "headache" },
        { text: "Is your headache severe or persistent?", symptom: "severe_headache", dependsOn: "headache" },
        { text: "Are you experiencing muscle aches?", symptom: "muscle_aches" },
        { text: "Are the muscle aches concentrated in a specific area?", symptom: "localized_muscle_aches", dependsOn: "muscle_aches" },
        { text: "Do you feel fatigued?", symptom: "fatigue" },
        { text: "Is your fatigue preventing you from doing daily activities?", symptom: "severe_fatigue", dependsOn: "fatigue" }
    ];

    let currentQuestionIndex = 0;
    const userSymptoms = [];

    const questionText = document.getElementById('questionText');
    const yesButton = document.getElementById('yesButton');
    const noButton = document.getElementById('noButton');
    const resetButton = document.getElementById('resetButton');
    const resultDiv = document.getElementById('result');
    const resultSection = document.getElementById('resultSection');

    function showNextQuestion() {
        while (currentQuestionIndex < questions.length) {
            const currentQuestion = questions[currentQuestionIndex];

            // Check if the question depends on a previous symptom and if that symptom was reported
            if (currentQuestion.dependsOn && !userSymptoms.includes(currentQuestion.dependsOn)) {
                currentQuestionIndex++;
            } else {
                questionText.textContent = currentQuestion.text;
                return;
            }
        }
        displayResult();
    }

    function handleAnswer(isYes) {
        if (isYes) {
            userSymptoms.push(questions[currentQuestionIndex].symptom);
        }
        currentQuestionIndex++;
        showNextQuestion();
    }

    function displayResult() {
        const symptomsMessage = generateSymptomMessage(userSymptoms);
        resultDiv.innerHTML = symptomsMessage;
        resultDiv.classList.remove('hidden');
        resultDiv.classList.add('visible');
    }

    function generateSymptomMessage(symptoms) {
        const mpoxSymptoms = ["fever", "high_fever", "rash", "spreading_rash", "swollen_lymph_nodes", "painful_lymph_nodes", "headache", "severe_headache", "muscle_aches", "localized_muscle_aches", "fatigue", "severe_fatigue"];
        const selectedMpoxSymptoms = symptoms.filter(symptom => mpoxSymptoms.includes(symptom));

        if (selectedMpoxSymptoms.length >= 5) {
            return "Your symptoms strongly suggest Mpox. Please consult a healthcare professional immediately.";
        } else if (selectedMpoxSymptoms.length > 2) {
            return "Your symptoms are somewhat consistent with Mpox. It's recommended to consult a healthcare provider.";
        } else {
            return "Your symptoms do not strongly match those of Mpox. However, if you feel unwell, it's always good to consult a healthcare provider.";
        }
    }

    function resetApp() {
        currentQuestionIndex = 0;
        userSymptoms.length = 0;
        resultDiv.classList.remove('visible');
        resultDiv.classList.add('hidden');
        showNextQuestion();
    }

    yesButton.addEventListener('click', () => handleAnswer(true));
    noButton.addEventListener('click', () => handleAnswer(false));
    resetButton.addEventListener('click', resetApp);

    // Start the questionnaire
    showNextQuestion();
});